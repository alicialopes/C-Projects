typedef struct calculo calculo;

float somar(calculo *num1, calculo *num2, float *result);
float subtrair(calculo *num1, calculo *num2, float *result);
float multiplicar(calculo *num1, calculo *num2, float *result);
float dividir(calculo *num1, calculo *num2, float *result);
