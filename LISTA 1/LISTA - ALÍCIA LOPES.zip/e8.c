#include <stdio.h>
#include <stdlib.h>

int main()
{
    // Leia um n�mero inteiro e imprima o seu antecessor e o seu sucessor.

    int num = 12;

    printf("numero: %d\n", num);
    printf("antecessor: %d\n", num-1);
    printf("sucessor: %d\n\n", num+1);

    system("pause");
    return 0;
}


