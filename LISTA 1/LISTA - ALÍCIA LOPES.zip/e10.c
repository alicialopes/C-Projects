#include <stdio.h>
#include <stdlib.h>

int main() {
    // Leia o tamanho do lado de um quadrado e imprima como resultado a sua �rea

    int lado = 5;
    printf("lado do quadrado mede %dcm\n" , lado);
    printf("area do quadrado: %dcm^2\n\n", lado*lado);

    system("pause");
    return 0;
}
