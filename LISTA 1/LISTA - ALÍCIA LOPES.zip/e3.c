#include <stdio.h>
#include <stdlib.h>

int main()
{
    //  Efetue a leitura de um n�mero real e
    // imprima o resultado do quadrado desse n�mero.

    float num = 1.6;
    printf("%.2f * %.2f = %.2f\n", num, num, num * num);

    system("pause");
    return 0;
}

