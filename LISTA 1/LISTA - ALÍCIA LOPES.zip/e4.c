#include <stdio.h>
#include <stdlib.h>

int main()
{
    // Leia um n�mero real e imprima a quinta parte deste n�mero.

    float num = 4.8;
    printf("a quinta parte %.2f = %.2f\n", num, num/5);

    system("pause");
    return 0;
}

