#include <stdio.h>
#include <stdlib.h>

int main()
{
    // Fa�a um programa que leia um n�mero inteiro e o imprima,
    // ent�o leia um n�mero real e tamb�m o imprima.


    // inteiro
    int num1 = 1;
    printf("numero inteiro: %d", num1);

    // real
    float num2 = 2.5;
    printf("\nnumero real: %.1f", num2);

    system("pause");
    return 0;
}
